<?php

namespace App\Filament\Resources\AngsuranResource\Pages;

use App\Filament\Resources\AngsuranResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAngsuran extends CreateRecord
{
    protected static string $resource = AngsuranResource::class;
}
