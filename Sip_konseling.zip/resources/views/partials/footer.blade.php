<div class="bgded overlay row4" style="background-image:url('{{ asset('images/masjid.jpg') }}');background-size: cover;">
    <footer id="footer" class="hoc clear">
      <div class="center btmspace-50">
        <h6 class="heading">SMAS AL - ULUM TERPADU</h6>
        <ul class="faico clear">
            <li><a class="faicon-facebook" href=""><i class="fab fa-facebook"></i></a></li>
            <li><a class="faicon-facebook" href=""><i class="fab fa-instagram"></i></a></li>
            <li><a class="faicon-twitter" href=""><i class="fab fa-twitter"></i></a></li>
        </ul>
        <p class="nospace">Konseling pelanggaran dan prestasi</p>
      </div>
      <hr class="btmspace-50">
      <div class="group btmspace-50">
      </div>
    </footer>
  </div>

  <div class="wrapper row5">
    <div id="copyright" class="hoc clear">
      <p class="fl_left">Copyright &copy; 2024 - All Rights Reserved - <a href="#">SMAS AL - ULUM TERPADU</a></p>
      <p class="fl_right">Design by <a target="_blank" href="" title="#">SMAS AL - ULUM TERPADU</a></p>
    </div>
  </div>
  <a id="backtotop" href="#top"><i class="fas fa-chevron-up"></i></a>
  <!-- JAVASCRIPTS -->
  <script src="{{ asset('js/jquery.min.js') }}"></script>
  <script src="{{ asset('js/jquery.backtotop.js') }}"></script>
  <script src="{{ asset('js/jquery.mobilemenu.js') }}"></script>

  @stack('script')
  </body>
  </html>


